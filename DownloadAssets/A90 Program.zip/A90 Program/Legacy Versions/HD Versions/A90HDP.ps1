# Program
cd 'C:\ShellyPrograms\A90 Program'
$SleepDuration = 200

# Load the necessary .NET assemblies
Add-Type -AssemblyName PresentationCore, PresentationFramework, WindowsBase
Add-Type -LiteralPath C:\Windows\Microsoft.NET\Framework64\v4.0.30319\System.Windows.Forms.dll; [System.Windows.Forms.Form]

while ($true) {
	Start-Process -FilePath "./A90SFX-1.exe" -WindowStyle Hidden




    # Create the WPF window
    $window = New-Object Windows.Window
    $window.WindowStyle = 'None'            # No window borders or title
    $window.AllowsTransparency = $true      # Enable transparency
    $window.Background = [Windows.Media.Brushes]::Transparent  # Set the background to transparent
    $window.Topmost = $true                 # Ensure the window is always on top
    $window.ResizeMode = 'NoResize'         # Disable resizing

    # Create an image control to hold the picture
    $image = New-Object Windows.Controls.Image

    
	
    # Load images
    $bitmap1 = [Windows.Media.Imaging.BitmapImage]::new([uri]::new("C:\ShellyPrograms\A90 Program\A90-1.png"))
    $stopSign = [Windows.Media.Imaging.BitmapImage]::new([uri]::new("C:\ShellyPrograms\A90 Program\StopSign.png"))
    $bitmap2 = [Windows.Media.Imaging.BitmapImage]::new([uri]::new("C:\ShellyPrograms\A90 Program\A90-2.png"))
    $bitmap3 = [Windows.Media.Imaging.BitmapImage]::new([uri]::new("C:\ShellyPrograms\A90 Program\A90-3.png"))

    # Add the image control to the window
    $window.Content = $image
	
    # Show the initial image
    $window.Show()
	# Start SFX
	






    # Set the initial image to A90-1, show A90, and set the window size
    $image.Source = $bitmap1
    $window.Width = $bitmap1.PixelWidth
    $window.Height = $bitmap1.PixelHeight
	
	sleep 1

	# Set the image to StopSign
    $image.Source = $stopSign
    $window.Width = $stopSign.PixelWidth
    $window.Height = $stopSign.PixelHeight


    # Define the time duration to monitor (in seconds)
    $monitorDuration = 0.1

    # Get the initial mouse position
    $initialPosition = [System.Windows.Forms.Cursor]::Position

    # Store the start time
    $startTime = Get-Date

    # Function to check mouse movement
    function Check-MouseMovement {
        $currentPosition = [System.Windows.Forms.Cursor]::Position
        return $initialPosition -ne $currentPosition
    }

    # Initialize a flag to check if the mouse has moved
    $mouseMoved = $false

    # Monitor mouse movement for the defined duration
    while ((Get-Date) -lt $startTime.AddSeconds($monitorDuration)) {
        Start-Sleep -Milliseconds 500 # Check every 500 milliseconds
        if (Check-MouseMovement) {
            $mouseMoved = $true
            break
        }
    }

    # Run your code if the mouse moved
    if ($mouseMoved) {
        Write-Host "Mouse moved during the monitoring period."
        # Place your code here that you want to run
        Start-Process -FilePath "cmd.exe" -ArgumentList "/c start /b ./A90SFX-2.exe" -WindowStyle Hidden
		sleep 2.6
        $image.Source = $bitmap2
        $window.Width = $bitmap2.PixelWidth
        $window.Height = $bitmap2.PixelHeight
        $window.Show()
        Start-Sleep -Milliseconds $SleepDuration
        $image.Source = $bitmap3
        $window.Width = $bitmap3.PixelWidth
        $window.Height = $bitmap3.PixelHeight
        Start-Sleep -Milliseconds $SleepDuration
        $image.Source = $bitmap2
        $window.Width = $bitmap2.PixelWidth
        $window.Height = $bitmap2.PixelHeight
        Start-Sleep -Milliseconds $SleepDuration
        $image.Source = $bitmap3
        $window.Width = $bitmap3.PixelWidth
        $window.Height = $bitmap3.PixelHeight
        Start-Sleep -Milliseconds $SleepDuration
        $image.Source = $bitmap2
        $window.Width = $bitmap2.PixelWidth
        $window.Height = $bitmap2.PixelHeight
        Start-Sleep -Milliseconds $SleepDuration
        $image.Source = $bitmap3
        $window.Width = $bitmap3.PixelWidth
        $window.Height = $bitmap3.PixelHeight
        Start-Sleep -Milliseconds $SleepDuration
    }
	$window.Hide()
    # Randomly generate a delay between 1 and 2 minutes (60 to 120 seconds)
    $randomDelay = Get-Random -Minimum 60 -Maximum 120
    Start-Sleep -Seconds $randomDelay
}
