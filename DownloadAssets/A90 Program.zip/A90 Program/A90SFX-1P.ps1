$wavFilePath = "C:\ShellyPrograms\A90 Program\A90SFX-1.wav"

$soundPlayer = New-Object System.Media.SoundPlayer
$soundPlayer.SoundLocation = $wavFilePath

# Preload the sound to reduce the delay before playing
$soundPlayer.Load()
$soundPlayer.PlaySync()
