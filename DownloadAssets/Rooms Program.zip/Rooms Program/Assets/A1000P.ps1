taskkill /f /im RoomsVisible.exe
taskkill /f /im RoomsFVisible.exe