#All programs

$A60touched = 0
$A120touched = 0
$path = "C:\ShellyPrograms\Rooms Program\Assets"

Set-Location $path

# Load the necessary .NET assemblies
Add-Type -AssemblyName PresentationCore, PresentationFramework, WindowsBase
Add-Type -LiteralPath C:\Windows\Microsoft.NET\Framework64\v4.0.30319\System.Windows.Forms.dll; [System.Windows.Forms.Form]

Add-Type @"
using System;
using System.Runtime.InteropServices;

public class KeyPress
{
    [DllImport("user32.dll")]
    public static extern short GetAsyncKeyState(int vKey);
}
"@

#A60 Program
function A60 {
    # Create the WPF window
    $screenHeight = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds.Height
    $window = New-Object Windows.Window
    $window.WindowStyle = 'None'            # No window borders or title
    $window.AllowsTransparency = $true      # Enable transparency
    $window.Background = [Windows.Media.Brushes]::Transparent  # Set the background to transparent
    $window.Topmost = $true                 # Ensure the window is always on top
    $window.ResizeMode = 'NoResize'         # Disable resizing

    # Create an image control to hold the picture
    $image = New-Object Windows.Controls.Image

    # Load images
    $bitmap1 = [Windows.Media.Imaging.BitmapImage]::new([uri]::new("C:\ShellyPrograms\Rooms Program\Assets\A60\A60.png"))

    # Add the image control to the window
    $window.Content = $image
	
    # Show the initial image past the screen
    $window.Show()
    $image.Source = $bitmap1
    $window.Width = $bitmap1.PixelWidth * 3
    $window.Height = $bitmap1.PixelHeight * 3
    $window.Top = ($screenHeight - $window.Height) / 2 - 60
    $window.Left = -1200 #($screenWidth - $window.Width)

    #Start SFX
    $SoundPlayer = New-Object System.Media.SoundPlayer
    $SoundPlayer.SoundLocation = "C:\ShellyPrograms\Rooms Program\Assets\A60\A60SFX.wav"
    $SoundPlayer.Play()  # Asynchronous playback
    start-sleep -Seconds 3.5


    for ($i = 1; $i -le 500; $i++) {
        $window.Left = $window.Left + 10
        $cursorPosition = [System.Windows.Forms.Cursor]::Position
        # Display the coordinates
        $x = $cursorPosition.X
        $y = $cursorPosition.Y
        if ($y -lt 1039) {
            if ($x -gt $window.Left -and $x -lt $window.left + 1128) {
                $A60touched = 1
                Write-Host "A60 Touched"
            }
        }
        start-sleep -seconds 0.1
    }
    $window.Close()
}

#A90 Program
function A90 {
    $SleepDuration = 200
    # Create the WPF window
    $window = New-Object Windows.Window
    $window.WindowStyle = 'None'            # No window borders or title
    $window.AllowsTransparency = $true      # Enable transparency
    $window.Background = [Windows.Media.Brushes]::Transparent  # Set the background to transparent
    $window.Topmost = $true                 # Ensure the window is always on top
    $window.ResizeMode = 'NoResize'         # Disable resizing

    # Create an image control to hold the picture
    $image = New-Object Windows.Controls.Image

    # Load images
    $bitmap1 = [Windows.Media.Imaging.BitmapImage]::new([uri]::new("C:\ShellyPrograms\Rooms Program\Assets\A90\A90-1.png"))
    $stopSign = [Windows.Media.Imaging.BitmapImage]::new([uri]::new("C:\ShellyPrograms\Rooms Program\Assets\A90\StopSign.png"))
    $bitmap2 = [Windows.Media.Imaging.BitmapImage]::new([uri]::new("C:\ShellyPrograms\Rooms Program\Assets\A90\A90-2.png"))
    $bitmap3 = [Windows.Media.Imaging.BitmapImage]::new([uri]::new("C:\ShellyPrograms\Rooms Program\Assets\A90\A90-3.png"))

    # Add the image control to the window
    $window.Content = $image
	
    # Show the initial image
    $window.Show()
	
    # Start SFX
    $SoundPlayer = New-Object System.Media.SoundPlayer
    $SoundPlayer.SoundLocation = "C:\ShellyPrograms\Rooms Program\Assets\A90\Start.wav"
    $SoundPlayer.Play()  # Asynchronous playback

    # Set the initial image to A90-1, show A90, and set the window size
    $image.Source = $bitmap1
    $window.Width = $bitmap1.PixelWidth
    $window.Height = $bitmap1.PixelHeight
	
	Start-Sleep 0.6

	# Set the image to StopSign
    $image.Source = $stopSign
    $window.Width = $stopSign.PixelWidth
    $window.Height = $stopSign.PixelHeight

    # Define the time duration to monitor (in seconds)
    $monitorDuration = 0.1

    # Get the initial mouse position
    $initialPosition = [System.Windows.Forms.Cursor]::Position

    # Store the start time
    $startTime = Get-Date

    # Function to check mouse movement
    function Check-MouseMovement {
        $currentPosition = [System.Windows.Forms.Cursor]::Position
        return $initialPosition -ne $currentPosition
    }

    # Initialize a flag to check if the mouse has moved
    $mouseMoved = $false
    $KeyPressed = $false

    # Monitor mouse movement for the defined duration
    while ((Get-Date) -lt $startTime.AddSeconds($monitorDuration)) {
        Start-Sleep -Milliseconds 500

        # Check mouse movement
        $mouseMoved = Check-MouseMovement

        # Check key presses
        $KeyPressed = $false
        for ($vKey = 0x01; $vKey -le 0xFE; $vKey++) {
            if ([KeyPress]::GetAsyncKeyState($vKey) -band 0x8000) {
                $KeyPressed = $true
                break
            }
        }

        # Break the loop if either condition is true
        if ($mouseMoved -or $KeyPressed) {
            Write-Host "A90 Activated"
            break
        }
    }

    # Run your code if the mouse moved
    if ($mouseMoved -or $KeyPressed) {
        Write-Host "Mouse moved during the monitoring period."
        # --- FIX: Defined screen width and height variables ---
		$screenHeight = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds.Height
    	$screenWidth = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds.Width
		$windowWidth = $window.Width
		$windowHeight = $window.Height
		# --------------------------------------------------------

		# Calculate the position to center the window
		$centerX = [math]::Floor(($screenWidth - $windowWidth) / 2)
		$centerY = [math]::Floor(($screenHeight - $windowHeight) / 2)

		# Set the window's position
		$Window.Left = $centerX
		$Window.Top = $centerY
		$SoundPlayer = New-Object System.Media.SoundPlayer
		$SoundPlayer.SoundLocation = "C:\ShellyPrograms\Rooms Program\Assets\A90\Death.wav"
		$SoundPlayer.Play()  # Asynchronous playback
        $image.Source = $bitmap2
        $window.Width = $bitmap2.PixelWidth
        $window.Height = $bitmap2.PixelHeight
        $window.Show()
        Start-Sleep -Milliseconds $SleepDuration
        $image.Source = $bitmap3
        $window.Width = $bitmap3.PixelWidth
        $window.Height = $bitmap3.PixelHeight
        Start-Sleep -Milliseconds $SleepDuration
        $image.Source = $bitmap2
        $window.Width = $bitmap2.PixelWidth
        $window.Height = $bitmap2.PixelHeight
        Start-Sleep -Milliseconds $SleepDuration
        $image.Source = $bitmap3
        $window.Width = $bitmap3.PixelWidth
        $window.Height = $bitmap3.PixelHeight
        Start-Sleep -Milliseconds $SleepDuration
        $image.Source = $bitmap2
        $window.Width = $bitmap2.PixelWidth
        $window.Height = $bitmap2.PixelHeight
        Start-Sleep -Milliseconds $SleepDuration
        $image.Source = $bitmap3
        $window.Width = $bitmap3.PixelWidth
        $window.Height = $bitmap3.PixelHeight
        Start-Sleep -Milliseconds $SleepDuration
    }
    $window.Hide()
    $window.Close()

}

function A120 { 
    $SoundPlayer = New-Object System.Media.SoundPlayer
    $SoundPlayer.SoundLocation = "C:\ShellyPrograms\Rooms Program\Assets\A120\A120.wav"
    $SoundPlayer.Play()  # Asynchronous playback

    # Create the WPF window
    $screenHeight = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds.Height
    $screenWidth = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds.Width
    $window = New-Object Windows.Window
    $window.WindowStyle = 'None'            # No window borders or title
    $window.AllowsTransparency = $true      # Enable transparency
    $window.Background = [Windows.Media.Brushes]::Transparent  # Set the background to transparent
    $window.Topmost = $true                 # Ensure the window is always on top
    $window.ResizeMode = 'NoResize'         # Disable resizing

    # Create an image control to hold the picture
    $image = New-Object Windows.Controls.Image

    # Load images
    $bitmap1 = [Windows.Media.Imaging.BitmapImage]::new([uri]::new("C:\ShellyPrograms\Rooms Program\Assets\A120\A120.png"))

    # Add the image control to the window
    $window.Content = $image
	
    # Show the initial image past the screen
    $window.Show()
    $image.Source = $bitmap1
    $window.Width = $bitmap1.PixelWidth
    $window.Height = $bitmap1.PixelHeight
    $window.Top = ($screenHeight - $window.Height) / 2 - 60
    $window.Left = -1200
    $window.Top = -220
    # --- START: CORRECTED MOVEMENT LOOP ---
    $direction = 1  # 1 moves right, -1 moves left
    $speed = 40    # Pixels to move per step
    $rightBoundary = $screenWidth + 100
    $leftBoundary = -($window.Width) - 100

    for ($i = 1; $i -le 500; $i++) {
        # If window goes past the right edge, reverse direction
        if ($window.Left -ge $rightBoundary) {
            $direction = -1
            $window.Top = 220
        }
        # If window goes past the left edge, reverse direction
        elseif ($window.Left -le $leftBoundary) {
            $direction = 1
            $window.Top = -220
        }
        
        # Move the window
        $window.Left = $window.Left + ($speed * $direction)
        
        # Cursor tracking logic
        $cursorPosition = [System.Windows.Forms.Cursor]::Position
        $x = $cursorPosition.X
        $y = [math]::abs($cursorPosition.Y - 1079)
        if ($direction -eq 1) {
            if ($y -ge 450) {
                if ($x -gt $window.Left -and $x -lt $window.left + 1500) {
                    $A120touched = 1
                    Write-Host "A120 Touched"
                }
            }
        } else {
            if ($y -le 650) {
                if ($x -gt $window.Left -and $x -lt $window.left + 1500) {
                    $A120touched = 1
                    Write-Host "A120 Touched"
                    }
            }   

        }
        start-sleep -Milliseconds 20
    }
    # --- END: CORRECTED MOVEMENT LOOP ---

    $window.Close()
}

$Sleeptime = Get-random -Minimum 10 -Maximum 41
$Monstertype = Get-random -Minimum 1 -Maximum 4

for ($j = 1; $j++) {
    $Sleeptime = Get-random -Minimum 10 -Maximum 41
    $Monstertype = Get-random -Minimum 1 -Maximum 4
    start-sleep -seconds $Sleeptime
    if ($Monstertype -eq 1) {
        A60
    } elseif ($Monstertype -eq 2) {
        A90
    } else {
        A120
    }
    
}