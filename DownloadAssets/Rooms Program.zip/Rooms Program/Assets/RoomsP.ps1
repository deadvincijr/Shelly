Add-Type -AssemblyName PresentationCore, PresentationFramework, WindowsBase
Add-Type -LiteralPath C:\Windows\Microsoft.NET\Framework64\v4.0.30319\System.Windows.Forms.dll; [System.Windows.Forms.Form]

Add-Type @"
using System;
using System.Runtime.InteropServices;

public class KeyPress
{
    [DllImport("user32.dll")]
    public static extern short GetAsyncKeyState(int vKey);
}
"@

$SoundPlayer = New-Object System.Media.SoundPlayer
$SoundPlayer.SoundLocation = "C:\ShellyPrograms\Rooms Program\Assets\CuriousLight.wav"
$SoundPlayer.Play()  # Asynchronous playback

Clear-Host

$Userinput = Read-Host "Welcome to DSFH desktop Rooms Service. Please select if you would like the monsters to be friendly or dangerous.(1/2)"
if ($Userinput -eq 1) {
    start-process -FilePath "C:\ShellyPrograms\Rooms Program\Assets\RoomsVisible.exe" -WindowStyle Hidden
} elseif ($Userinput -eq 2) {
    start-process -FilePath "C:\ShellyPrograms\Rooms Program\Assets\RoomsFVisible.exe" -WindowStyle Hidden
} else {
    write-host "Please type 1 or 2 to decide."
    Start-sleep -seconds 5
}